<html>
    <head><title>Kritik dan Saran ~ Inputan Textarea</title></head>
    <body>
        <FORM ACTION="proses09.php" METHOD="POST" NAME="input">
            <h2>Input Kritik / Saran :</h2>
            <textarea name="saran" cols="40" rows="5"></textarea><br>
            <input type="submit" name="Proses" value="input saran"> 

        </FORM>
</body>
</html>            