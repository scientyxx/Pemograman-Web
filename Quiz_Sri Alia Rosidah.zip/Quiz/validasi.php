<html>
    <head><title>PHP Form Validation</title></head>
    <h2>PHP Form Validation</h2>
    <body>
        <FORM ACTION="proses_validasi.php" METHOD="POST" NAME="input">
            Nama: <input type="text" name="nama"><br><br>
            E-mail: <input type="text" name="email"><br><br>
            Website: <input type="text" name="website"><br><br>
            Comment:  <textarea name="komen" cols="40" rows="5"></textarea><br><br>
            Gender: <input type="radio" name="gender" value="Female" checked> Female
            <input type="radio" name="gender" value="Male"> Male<br><br>
            
            <input type= "submit" name = "submit" value="submit">
        </FORM>
    </body>
</httml>