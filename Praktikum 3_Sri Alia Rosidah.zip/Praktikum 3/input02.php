<html>
    <head><title>Pengolahan Form</title></head>
    <body>
        <FORM ACTION="proses02.php" METHOD="POST" NAME="input">
            Nama Anda : <input type="text" name="nama"><br>
            <input type= "submit" name = "input" value="input">
        </FORM>
    </body>
</httml>