<?php
if (isset($_GET['input'])){
    $nama = $_GET['nama'];
    echo "Nama Anda : <br> $nama</br>";
}
?>