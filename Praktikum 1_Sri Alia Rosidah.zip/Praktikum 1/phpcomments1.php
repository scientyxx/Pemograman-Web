<!DOCTYPE html>
<html>
<body>

<?php
// This is a single-line comment

# This is also a single-line commnet

?>

</body>
</html>