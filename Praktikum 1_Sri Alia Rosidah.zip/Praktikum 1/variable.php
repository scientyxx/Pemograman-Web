<?php
$nim = "0411500400";
$nama = 'Chotimatul Musyarofah';

echo "Nim   : " . $nim . "<br>";
echo "Nama  : $nama";

?>