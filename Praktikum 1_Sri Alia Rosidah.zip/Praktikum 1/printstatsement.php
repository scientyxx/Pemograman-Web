<!DOCTYPE html>
<html>
<body>

<?php
print "<h2> PHP is Fun!</h2>";
print "Hayoo Gabung Kelas PHP!<br>";
print "Bukan Pemberi Harapan Palsu Lohh yaa!";
?>

</body>
</html>