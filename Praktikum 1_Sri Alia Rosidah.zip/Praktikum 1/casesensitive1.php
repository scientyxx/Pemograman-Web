<!DOCTYPE html>
<html>
<body>

<?php
ECHO "Hello Boy!<br>";
echo "Hello Girl!<br>";
Echo "Hello Gay!";
?>

</body>
</html>