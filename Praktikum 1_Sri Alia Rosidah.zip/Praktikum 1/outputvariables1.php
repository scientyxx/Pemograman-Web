<!DOCTYPE html>
<html>
<body>

<?php
$txt = "Three Girls";
echo " I love $txt!";
?>

</body>
</html>